"""README generator implementations."""
